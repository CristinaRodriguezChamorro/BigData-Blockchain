  #EJERCICIO 1.CUPON DE LA ONCE.
  
  x <- runif(1000,min = 0000,max = 9999)
  x <- as.integer(x)
  length(which(x%%2 == 0))
  
  #Otra forma
  x <- runif(1000,min = 0000,max = 9999)
  x <- as.integer(x)
  cont <- 0
  i <- 1
  while( i <= length(x)){
    numeroAleatorio <- x[i]
    Resto <- numeroAleatorio%%2
    if(Resto == 0 && numeroAleatorio != 0){
      cont <- cont + 1;
    }
    i <- i + 1
  }
  print(cont)
  
  #EJERCICIO 2. CHALETS CONSTRUIDOS POR 10 PROMOTORAS.
  
  #2. a) 
  
  Chalets <- read.table("C:\\Users\\cristina.rodriguez-c\\Documents\\Master\\datos\\chalets.txt", header=TRUE)
  
  #2. b) 
  
  var = apply(Chalets, 2, mean) 
  print(c(var[2],var[4]))
  
  #2 c)
  
  
    
    func <- function(x){
          matriz <- matrix(c(0,0),ncol = ncol(x), nrow = nrow(x))
          VectorSuma <- c(1:ncol(x))
          VectorFisher <- c(1:ncol(x))
          Media <- apply(x, 2, mean)
          DesviacionTipica <- (apply(x, 2, sd))
          for(j in seq_len(ncol(x))){
              for(i in seq_len(nrow(x))){
                 matriz[i,j] <- (x[i,j] - Media[j])^3
              }
            VectorSuma[j] <- sum(matriz[,j])
            VectorFisher[j] <- VectorSuma[j]/(ncol(x)*DesviacionTipica[j]^3)
          }
          cbind(Media,DesviacionTipica,VectorFisher)
    }
    func(Chalets)
    
  #3.Escriba una funcion que convierta centimetros a kens y shakus
    
  conversionUnidades <- function(numero){
    if(numero > 0){
      shakus <- numero/30.3
      ken <- shakus*6
      cbind(shakus,ken) 
    }else{
      print("Error. Introduce numeros positivos") 
    }
  }
  
  #Ejemplo: 
  conversionUnidades(5)
  
  #4.INVESTIGADOS PRECIOS POR ESTANCIA. 
  
  # Determinar la distribucion de precios: 
  
  # 4.a) Sin agrupar en intervalos.
  
  VectorPrecios <- c(7000,3000,5000,4000,5000,7000,4000,7500,8000,
                     5000,5000,500,3000,7000,10000,15000,5000,7500,
                     12000,8000,4000,5000,3000,5000,10000,3000,4000,5000,
                     7000,5000,3000,4000,7000,4000,7000,5000,4000,7000,10000,
                     7500,7000,8000,7500,7000,7500,8000,7000,7000,12000,8000)
  
  Datos <- table(VectorPrecios)
  
  
  #4.b) Vamos a agrupar por intervalos determinados.
  
  DatosIntervalos <- cut(Datos, 5)
  matriz <- as.matrix(table(DatosIntervalos)) 
  barplot(matriz[,1], xlab='Precio en $', ylab='Frecuencia Absoluta', main='Precios agrupados')
  
  #5.- Dado el fichero de datos Empleados.dat se pide: 
  
  #a) Crear un fichero permanente Empleados.RData.
  
  Empleados <-read.table("C:\\Users\\cristina.rodriguez-c\\Documents\\Master\\datos\\Empleados.dat", header=TRUE)
  save(Empleados, file = "Empleados.RData")
  load("Empleados.RData")
  
  #b) Selecciona las 10 primeras filas de la variable salini.
  
  Empleados$salini[1:10]
  
  #c) Seleccione las filas 4 y 8 de la variable salario. 
  
  c(Empleados$salario[4],Empleados$salario[8])
  
  #d) Seleccione el elemento 3 de la columna 4.
  
  Empleados$educ[3]
  #o
  Empleados[3,4]
  
  #e) Seleccione las columnas 1 y 4 de dos formas distintas.�Los objetos son los mismos?
  
  #Primera forma
  class(Empleados$educ)
  mode(Empleados$educ)
  mode(Empleados$id)
  class(Empleados$id)
  
  #Segunda forma
  class(subset(Empleados, select=c(id,educ)))
  mode(subset(Empleados, select=c(id,educ)))
  

  #f) Seleccione los casos que verifican 23000 < salario < 25500 y educ > 7.
  
  subset(Empleados, salario>23000 & salario<25500 & educ > 7)
  
  
  
  #g) Seleccione los casos con valores en todas las variables (donde tenga sentido) por encima del correspondiente tercer cuartil. (?quantile) 
  
  VectorId <- Empleados$id
  VectorEduc <- Empleados$educ
  VectorSalario <- Empleados$salario
  VectorSalini <- Empleados$salini
  VectorTiempemp <- Empleados$tiempemp
  VectorExpprev <- Empleados$expprev
  
  #Agrupamos los valores del tercer cuartil correspondiente a cada columna del dataframe en cuestion. 
  CondicionA <- quantile(VectorId,0.75)
  CondicionB <- quantile(VectorEduc,0.75)
  CondicionC <- quantile(VectorSalario,0.75)
  CondicionD <- quantile(VectorSalini,0.75)
  CondicionE <- quantile(VectorTiempemp,0.75)
  CondicionF <- quantile(VectorExpprev,0.75)
  
  #Ahora se generan los dataframe que cumplan las condiciones establecidas.
  #Posteriormente se uniran todos los dataframe y se eliminaran las filas repetidas.
  ID <- subset(Empleados, Empleados$id > CondicionA)
  EDUC <- subset(Empleados, Empleados$educ > CondicionB)
  SALARIO <- subset(Empleados, Empleados$salario > CondicionC)
  SALINE <- subset(Empleados, Empleados$salini > CondicionD)
  TIEMPEMP <- subset(Empleados, Empleados$tiempemp > CondicionE)
  EXPPREV <- subset(Empleados, Empleados$expprev > CondicionF)
  
  df <- rbind(ID,EDUC,SALARIO,SALINE,TIEMPEMP,EXPPREV)
  df <- df[!duplicated(df), ]
  
  #Se muestra el data frame ordenado:
  df[order(df$id),]
  
  #6.Dado el conjunto de datos airquality (informaci�n meteorol�gica de ciertos meses de cierto a�o en Nueva York, que viene de serie en R "?data") realiza los siguientes gr�ficos: 
 
  data(airquality)
  airquality
  
  #GRAFICO 1
  plot(airquality$Solar.R, xlab = "", ylab = "dat", type = "l", col = "blue")
  lines(airquality$Ozone,type = "l", col = "red")
  lines(airquality$Temp, type = "l", col = "orange")
  lines(airquality$Wind,type = "l", col = "pink")
  legend(x = "topright", legend = c("Ozone", "Solar.R", "Wind", "Temp"),
         fill = c("red", "blue", "pink","orange"))
  
  #GRAFICO 2
  boxplot(airquality$Temp ~ airquality$Month,
          ylab = "Temperatura",
          xlab = "Meses",
          col = rainbow(5)
  )
