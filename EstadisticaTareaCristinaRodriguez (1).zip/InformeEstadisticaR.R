alumnos <- read.table("C:\\Users\\cristina.rodriguez-c\\Documents\\Master\\Estadistica\\Alumnos.txt", header=TRUE)


## Se recomienda instalar la siguiente libreria, para el calculo de la moda.
##install.packages('modeest')
##library(modeest)

###EJERCICIO 1.A
#Calculo de la media geometrica, y media aritmetica
media <- function(x){
  c(exp(sum(log(x))/length(x)), mean(x))
} 
media(alumnos$Estatura)
#Calculo de la mediana
median(alumnos$Estatura)
#Calculo de la desviacion tipica
sd(alumnos$Estatura)
#Calculo de la moda
mlv(alumnos$Estatura, method  =  "mfv")
#Los cuartiles
quantile(alumnos$Estatura,.25)
quantile(alumnos$Estatura,.50)
quantile(alumnos$Estatura,.75)
apply(alumnos,2,quantile)
#Deciles
quantile(alumnos$Estatura, prob = c(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9))
#Percentiles
quantile(alumnos$Estatura, c(.32, .57, .98)) 
#El rango
range(alumnos$Estatura)
#Varianza
var(alumnos$Estatura)
#Coeficiente de Person
sd(alumnos$Estatura)/mean(alumnos$Estatura)
#Diagrama de Caja y bigotes
boxplot(alumnos,main = "Diagrama de Caja y Bigotes", xlab = "Quantiles", ylab = "Estaturas", 
col = c("green3"), horizontal = TRUE)

###EJERCICIO 1. B

alumnosApartadoB <- read.table("C:\\Users\\cristina.rodriguez-c\\Documents\\Master\\Estadistica\\AlumnosB.txt", header=TRUE)
IntervalosEstatura <- cut(alumnosApartadoB$Estatura, breaks = 4, include.lowest = TRUE)
IntervalosPeso <- cut(alumnosApartadoB$Peso, breaks = 4, include.lowest = TRUE)
Tabla <- table(IntervalosEstatura,IntervalosPeso)
Tabla

###Ejercicio 2
install.packages("nortest")
library(nortest)

#Comprobamos con los siguientes comandos que ambas submuestras siguen una distribuci�n normal.
lillie.test(alumnos$Estatura[1:15])
ad.test(alumnos$Estatura[1:15])
pearson.test(alumnos$Estatura[1:15])
cvm.test(alumnos$Estatura[1:15])
sf.test(alumnos$Estatura[1:15])
shapiro.test(alumnos$Estatura[1:15])

lillie.test(alumnos$Estatura[16:30])
ad.test(alumnos$Estatura[16:30])
pearson.test(alumnos$Estatura[16:30])
cvm.test(alumnos$Estatura[16:30])
sf.test(alumnos$Estatura[16:30])
shapiro.test(alumnos$Estatura[16:30])

#Comprobamos que las varianzas son iguales
var.test(alumnos$Estatura[1:15],alumnos$Estatura[16:30])

#Obtencion del intervalo en cuestion
t.test(alumnos$Estatura[1:15],alumnos$Estatura[16:30], var.equal = TRUE)

