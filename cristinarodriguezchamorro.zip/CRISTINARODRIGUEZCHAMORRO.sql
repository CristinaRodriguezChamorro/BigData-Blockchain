DROP DATABASE IF EXISTS TIENDAPLICACION;
CREATE DATABASE TIENDAPLICACION;
USE TIENDAPLICACION;

-- Nota: En el presente script apareceran determinados comentarios que van a servir de guia, para favorecer la comprension de lo realizado. No obstante, se puede encontrar la explicacion detallada del modelo conceptual y relacional en el .pdf oficial de la entrega.

-- Creamos la tabla EMPRESA
CREATE TABLE EMPRESA(
            id INT NOT NULL AUTO_INCREMENT ,
            nombre VARCHAR(50) NOT NULL,
            pais VARCHAR(20),
            anoCreacion NUMERIC (4,0),
            correo VARCHAR(50),
            dirWeb VARCHAR(50),
            PRIMARY KEY (id)
);
-- Creamos la tabla EMPLEADO
CREATE TABLE EMPLEADO(
			experiencia NUMERIC(5,0),
            dni VARCHAR(10),
            calle VARCHAR(50),
            numero NUMERIC(2,0),
            codPostal NUMERIC(6,0),
            correo VARCHAR(50),
            telefonoPersonal NUMERIC(10,0),
            telefonoEmpresa NUMERIC(10,0),
            PRIMARY KEY(dni)
);
-- Creamos la tabla aplicacion
CREATE TABLE APLICACION(
			nombre VARCHAR(20) NOT NULL,
            fechaFin DATE NOT NULL,
            fechaInicio DATE NOT NULL,
            codigo VARCHAR(5),
            idCategoria NUMERIC(4,0) NOT NULL,
            memoria VARCHAR(10),
            precio FLOAT(10),
            PRIMARY KEY (codigo)
);

-- Creamos la tabla TIENE. En una relacion ternaria (N:M:P), que va a relacionar el empleado, con la empresa y con la aplicacion. 
-- De tal forma que, tal y como se explica en la documentacion, una empresa puede tener muchas aplicaciones y una aplicacion puede ser de varias empresas. Al mismo tiempo, una empresa tiene muchos empleados, y el empleado puede pertenecer a varias empresas. Y por ultimo, un empleado puede estar desarrollando varias aplicaciones (teniendo en cuenta que puede ser jefe), al mismo tiempo que una aplicacion puede estar siendo desarrollada por muchos empleados.
CREATE TABLE TIENE(
			fechafinEmpleado DATE,
            fechainiEmpleado DATE NOT NULL,
            jefe CHAR(2),
            idEmpresa INT NOT NULL AUTO_INCREMENT,
            codigoAplicacion VARCHAR(5),
            dniEmpleado VARCHAR(10),
            PRIMARY KEY(idEmpresa,codigoAplicacion,dniEmpleado),
            FOREIGN KEY(idEmpresa) REFERENCES EMPRESA(id),
            FOREIGN KEY(codigoAplicacion) REFERENCES APLICACION(codigo),
			FOREIGN KEY(dniEmpleado) REFERENCES EMPLEADO(dni)
);
-- Creamos la tabla USUARIO
CREATE TABLE USUARIO(
			numCuenta VARCHAR(50),
            nombre VARCHAR(20),
            apellido1 VARCHAR(20),
            apellido2 VARCHAR(20),
            calle VARCHAR(50),
            numero NUMERIC(2,0),
            codPostal NUMERIC(6,0),
            pais CHAR(10),
			telefono NUMERIC(10,0),
			PRIMARY KEY (numCuenta)
);

-- Esta tabla representa a la relacion presente entre usuario y aplicacion. Su cardinalidad es N:N. Se tiene que una aplicacion puede ser descargada por muchos usuarios, y que un mismo usuario puede descargarse muchas aplicaciones.
CREATE TABLE DESCARGA(
			comentario VARCHAR(50),
            puntuacion NUMERIC(1,0),
            fechaDescarga DATE NOT NULL,
            codAplicacion VARCHAR(5),
            numCuentaUsuario VARCHAR(10),
            PRIMARY KEY(codAplicacion,numCuentaUsuario),
            FOREIGN KEY(codAplicacion) REFERENCES APLICACION(codigo),
            FOREIGN KEY(numCuentaUsuario) REFERENCES USUARIO(numCuenta),
            CHECK (puntuacion <= 5)
);
-- NotaImportante: Al parecer el Check funciona en determinadas versiones de MySql. Yo estoy usando la 8.0.18, y me funciona correctamente.

-- Creacion de las tablas CATEGORIA, y TIENE_CATEGORIA, para hacer posible el hecho de que una aplicacion puede pertenecer a mas de una categoria. 
CREATE TABLE CATEGORIA(
			idCategoria NUMERIC(4,0) NOT NULL,
            nombreCategoria VARCHAR(20),
            PRIMARY KEY(idCategoria)
);
CREATE TABLE TIENE_CATEGORIA(
			idCateg NUMERIC(4,0) NOT NULL,
            codAplicacion VARCHAR(5),
            PRIMARY KEY(codAplicacion,idCateg),
            FOREIGN KEY(idCateg) REFERENCES CATEGORIA(idCategoria),
            FOREIGN KEY(codAplicacion) REFERENCES APLICACION(codigo)
);
-- Creacion de la tabla Tienda
CREATE TABLE TIENDA(
			nombre VARCHAR(30) NOT NULL,
            dirWeb VARCHAR(30),
			idEmpresa INT NOT NULL AUTO_INCREMENT,
            PRIMARY KEY(nombre),
            FOREIGN KEY(idEmpresa) REFERENCES EMPRESA(id)
);
-- Creacion de la tabla PERTENECE, referente a la relacion que existe entre la app y la tienda. Una aplicacion puede pertenecer a muchas tiendas, y una tienda tiene muchas aplicaciones.
CREATE TABLE PERTENECE(
		codApp VARCHAR(5),
        nombreTienda VARCHAR(50),
        PRIMARY KEY(codApp, nombreTienda),
        FOREIGN KEY(codApp) REFERENCES APLICACION(codigo),
        FOREIGN KEY(nombreTienda) REFERENCES TIENDA(nombre)
);

-- Insertamos los datos a todas las tablas: 

INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Apple", "Estados Unidos", 1976, "AppleApps@gmail.com", "http://www.Apple.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Android", "Estados Unidos", 2008, "GoogleAndroid@gmail.com", "https://www.android.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("BlackBerry", "Canadá", 1999, "BlackBerryMobile@gmail.com", "http://www.BlackBerryMobile.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("WindowsPhone", "Estados Unidos", 2010, "WindowsPhone@gmail.com", "http://www.WindowsPhone.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Nokia", "Finlandia",1865, "nokia@gmail.com", "http://www.nokia.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("HP", "California",2015, "hp@gmail.com", "http://www.hp.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Amazon", "Estados Unidos",1994, "Amazon@gmail.com", "http://www.Amazon.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Nokia", "Finlandia",1865, "nokia@gmail.com", "http://www.nokia.com"); 
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa1", "Finlandia",1865, "000@gmail.com", "http://www.Empresa1.com"); 
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa2", "Finlandia",1865, "001@gmail.com", "http://www.Emprzgzesa2.com"); 
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa3", "Finlandia",1865, "002@gmail.com", "http://www.Empreafgasa3.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa5", "Finlandia",1865, "00563@gmail.com", "http://www.Empcvresa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa6", "Finlandia",1865, "003423@gmail.com", "http://www.Empqresa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa6", "Finlandia",1865, "003437@gmail.com", "http://www.Empr<esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa7", "Finlandia",1865, "00763@gmail.com", "http://www.Emprefsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa8", "Finlandia",1865, "00373@gmail.com", "http://www.Emprefsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa9", "Finlandia",1865, "086703@gmail.com", "http://www.Emprejsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa10", "Finlandia",1865, "076703@gmail.com", "http://www.Emprjsja4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa11", "Finlandia",1865, "0068763@gmail.com", "http://www.Emprejsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa12", "Finlandia",1865, "012303@gmail.com", "http://www.Emprexccsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa13", "Finlandia",1865, "013203@gmail.com", "http://www.Emprcesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa14", "Finlandia",1865, "00133@gmail.com", "http://www.Empresjxga4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa15", "Finlandia",1865, "001373@gmail.com", "http://www.Empreszxcva4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa16", "Finlandia",1865, "868003@gmail.com", "http://www.Emprexcsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa17", "Finlandia",1865, "008763@gmail.com", "http://www.Emprxcvsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa18", "Finlandia",1865, "003767@gmail.com", "http://www.Emprexcvsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa19", "Finlandia",1865, "007673@gmail.com", "http://www.Emprxcvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa20", "Finlandia",1865, "003767@gmail.com", "http://www.Empxvcresa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa21", "Finlandia",1865, "006763@gmail.com", "http://www.Emprvxcesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa22", "Finlandia",1865, "006763@gmail.com", "http://www.Emprxvcxesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa23", "Finlandia",1865, "0dgd03@gmail.com", "http://www.Emprxcvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa24", "Finlandia",1865, "0sjsj03@gmail.com", "http://www.Empxcvxresa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa25", "Finlandia",1865, "003asga@gmail.com", "http://www.Emprxcvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa41", "Finlandia",1865, "00aga3@gmail.com", "http://www.Empresfsea4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa42", "Finlandia",1865, "003963@gmail.com", "http://www.Empresdfssa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa43", "Finlandia",1865, "0cghj403@gmail.com", "http://www.Emprdsfesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa44", "Finlandia",1865, "003fkjfk@gmail.com", "http://www.Emprsdfsesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa45", "Finlandia",1865, "00wrw3@gmail.com", "http://www.Emprefdssa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa46", "Finlandia",1865, "00sjy3@gmail.com", "http://www.Emprhñkesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa47", "Finlandia",1865, "00sh3@gmail.com", "http://www.Emprehklhsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa48", "Finlandia",1865, "00afhaf3@gmail.com", "http://www.Emklhkpresa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa49", "Finlandia",1865, "0aha03@gmail.com", "http://www.Emprehklhsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa50", "Finlandia",1865, "00aha3@gmail.com", "http://www.Emprklhsdfesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa51", "Finlandia",1865, "003opg@gmail.com", "http://www.Empresdfgza4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa52", "Finlandia",1865, "003zfgjz@gmail.com", "http://www.Empfgzresa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa53", "Finlandia",1865, "003zzt@gmail.com", "http://www.Emprezgfzsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa54", "Finlandia",1865, "003ztzh@gmail.com", "http://www.Empgfzresa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa55", "Finlandia",1865, "003zhz@gmail.com", "http://www.Emprezdfgzsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa56", "Finlandia",1865, "00zh3@gmail.com", "http://www.Emprzdfgesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa57", "Finlandia",1865, "088803@gmail.com", "http://www.Emprgfzesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa58", "Finlandia",1865, "009643@gmail.com", "http://www.Emprezfgsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa59", "Finlandia",1865, "005643@gmail.com", "http://www.Emprezfgsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa60", "Finlandia",1865, "003464@gmail.com", "http://www.Emprezdfgsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa61", "Finlandia",1865, "004643@gmail.com", "http://www.Emprefgsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa62", "Finlandia",1865, "005233@gmail.com", "http://www.Emprefgsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa63", "Finlandia",1865, "0048643@gmail.com", "http://www.Emprdfgesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa64", "Finlandia",1865, "0064863@gmail.com", "http://www.Emprfgzfesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa65", "Finlandia",1865, "004643@gmail.com", "http://www.Emprezfgsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa66", "Finlandia",1865, "006483@gmail.com", "http://www.Emprezdfgsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa67", "Finlandia",1865, "0046683@gmail.com", "http://www.Emprfgesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa68", "Finlandia",1865, "0046843@gmail.com", "http://www.Emprcfhesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa69", "Finlandia",1865, "0046843@gmail.com", "http://www.Emprexrrsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa70", "Finlandia",1865, "004643@gmail.com", "http://www.Emprzxcvzesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa71", "Finlandia",1865, "0048643@gmail.com", "http://www.Emprxcvzesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa72", "Finlandia",1865, "04643@gmail.com", "http://www.Emprescxvza4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa73", "Finlandia",1865, "00463@gmail.com", "http://www.Emprexcvsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa74", "Finlandia",1865, "00463@gmail.com", "http://www.Emprxcvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa75", "Finlandia",1865, "00643@gmail.com", "http://www.Emprexcvsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa76", "Finlandia",1865, "00486843@gmail.com", "http://www.Emprxcvzvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa77", "Finlandia",1865, "0046863@gmail.com", "http://www.Emprezxcvzsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa78", "Finlandia",1865, "004643@gmail.com", "http://www.Emprexzcvsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa79", "Finlandia",1865, "004643@gmail.com", "http://www.Emprxcvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa80", "Finlandia",1865, "004643@gmail.com", "http://www.Emprzxcvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa81", "Finlandia",1865, "004643@gmail.com", "http://www.Emprzxcvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa82", "Finlandia",1865, "004643@gmail.com", "http://www.Emprzxcvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa83", "Finlandia",1865, "004643@gmail.com", "http://www.Empxcvresa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa84", "Finlandia",1865, "00463@gmail.com", "http://www.Emprexcvsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa85", "Finlandia",1865, "0046843@gmail.com", "http://www.Empzxcbresa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa86", "Finlandia",1865, "004683@gmail.com", "http://www.Emprehkdhsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa87", "Finlandia",1865, "006483@gmail.com", "http://www.Empregafdgsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa88", "Finlandia",1865, "0048643@gmail.com", "http://www.Emprefgssa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa89", "Finlandia",1865, "004643@gmail.com", "http://www.Emprezxcvsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa90", "Finlandia",1865, "00643@gmail.com", "http://www.Emprefgafgsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa91", "Finlandia",1865, "00464@gmail.com", "http://www.Emprdgfesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa92", "Finlandia",1865, "0034684@gmail.com", "http://www.Empradfaesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa93", "Finlandia",1865, "0046483@gmail.com", "http://www.Emprsddfesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa94", "Finlandia",1865, "0048683@gmail.com", "http://www.Empresdfasa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa95", "Finlandia",1865, "004863@gmail.com", "http://www.Emprasdfsdesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa96", "Finlandia",1865, "00333@gmail.com", "http://www.Emprehyysa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa97", "Finlandia",1865, "0sf03@gmail.com", "http://www.Emprxgrrsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa98", "Finlandia",1865, "00zfg3@gmail.com", "http://www.Emprzfgfesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa99", "Finlandia",1865, "00hys3@gmail.com", "http://www.Emprergarsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa100", "Finlandia",1865, "0hsth03@gmail.com", "http://www.Emprfdgzesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa101", "Finlandia",1865, "0hdzhz03@gmail.com", "http://www.Emprgrresa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa102", "Finlandia",1865, "00xcvz3@gmail.com", "http://www.Emprrhaeesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa103", "Finlandia",1865, "00rhs3@gmail.com", "http://www.Empreszfzha4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa104", "Finlandia",1865, "00gjs3@gmail.com", "http://www.Emprezxcvfsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa105", "Finlandia",1865, "00xgz3@gmail.com", "http://www.Emprezvcxzxcsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa106", "Finlandia",1865, "0zdhz03@gmail.com", "http://www.Emprxcvxvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa107", "Finlandia",1865, "00zhz3@gmail.com", "http://www.Emprexcvxvsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa108", "Finlandia",1865, "003zhfz@gmail.com", "http://www.Emprxcvxvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa109", "Finlandia",1865, "00zag3@gmail.com", "http://www.Emprevzvczxsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa110", "Finlandia",1865, "00ga3@gmail.com", "http://www.Empresxcvxa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa111", "Finlandia",1865, "003<gz@gmail.com", "http://www.Emprxvxvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa112", "Finlandia",1865, "00<fd<3@gmail.com", "http://www.Emprexcvxsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa113", "Finlandia",1865, "00rgq3@gmail.com", "http://www.Emprwefqeewesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa114", "Finlandia",1865, "0SDF03@gmail.com", "http://www.Emprzvsdvdesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa115", "Finlandia",1865, "00<df<3@gmail.com", "http://www.Emprzbzdfvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa116", "Finlandia",1865, "00xfhz3@gmail.com", "http://www.Emprxcvxcesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa117", "Finlandia",1865, "0zga03@gmail.com", "http://www.Emprxcvxcsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa118", "Finlandia",1865, "00ggag3@gmail.com", "http://www.Emprexcvvsa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa119", "Finlandia",1865, "00agaa3@gmail.com", "http://www.Emprxcvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa120", "Finlandia",1865, "00yidty3@gmail.com", "http://www.Emprcvesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa121", "Finlandia",1865, "00fpfi3@gmail.com", "http://www.Emprwefweesa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa122", "Finlandia",1865, "00xux3@gmail.com", "http://www.Empre111sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa123", "Finlandia",1865, "00xuxf3@gmail.com", "http://www.Empr11esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa124", "Finlandia",1865, "00xhx3@gmail.com", "http://www.Empr22esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa125", "Finlandia",1865, "00xhgx3@gmail.com", "http://www.Emp222resa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa126", "Finlandia",1865, "00xhgx3@gmail.com", "http://www.Empr33esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa127", "Finlandia",1865, "00xhg3@gmail.com", "http://www.Empre345sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa128", "Finlandia",1865, "00,cjhc3@gmail.com", "http://www.Empre54sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa129", "Finlandia",1865, "00xjx3@gmail.com", "http://www.Empresa4534.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa130", "Finlandia",1865, "00xjx3@gmail.com", "http://www.Empres4534a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa1234", "Finlandia",1865, "0xx3@gmail.com", "http://www.Empr4esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa447", "Finlandia",1865, "0xjx03@gmail.com", "http://www.Empre5sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa471", "Finlandia",1865, "00xjx3@gmail.com", "http://www.Empres5a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4789", "Finlandia",1865, "00kgl3@gmail.com", "http://www.Empre5sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4147", "Finlandia",1865, "0afga03@gmail.com", "http://www.Empr44sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4123", "Finlandia",1865, "00zgzgf3@gmail.com", "http://www.Empr5esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa131", "Finlandia",1865, "00zfbzb3@gmail.com", "http://www.Empre49sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa132", "Finlandia",1865, "00bzb3@gmail.com", "http://www.Empresa444.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa133", "Finlandia",1865, "00zxcb3@gmail.com", "http://www.Empr99esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa134", "Finlandia",1865, "00zbz3@gmail.com", "http://www.Empres99a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa135", "Finlandia",1865, "00zbzb3@gmail.com", "http://www.Empre777sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa136", "Finlandia",1865, "0fh03@gmail.com", "http://www.Empresa8884.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa137", "Finlandia",1865, "00,kv3@gmail.com", "http://www.Empres44a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa138", "Finlandia",1865, "00cnmc3@gmail.com", "http://www.Empre444sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa139", "Finlandia",1865, "00nmb3@gmail.com", "http://www.Empre789sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa140", "Finlandia",1865, "00bxgo@gmail.com", "http://www.Empres888a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa142", "Finlandia",1865, "0xnx03@gmail.com", "http://www.Empres788a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa143", "Finlandia",1865, "00nxn3@gmail.com", "http://www.Empres7777a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa144", "Finlandia",1865, "00jxhjx3@gmail.com", "http://www.Empre996sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa145", "Finlandia",1865, "0xghx03@gmail.com", "http://www.Empre6969a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa146", "Finlandia",1865, "003xhx@gmail.com", "http://www.Empres3666a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa147", "Finlandia",1865, "00zhz3@gmail.com", "http://www.Empres454a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa148", "Finlandia",1865, "00zfhz3@gmail.com", "http://www.Empre4564sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa149", "Finlandia",1865, "00zfhz<3@gmail.com", "http://www.Empr4564esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa150", "Finlandia",1865, "00zfhz3@gmail.com", "http://www.Empr4564esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa151", "Finlandia",1865, "00zhz3@gmail.com", "http://www.Empres56a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa152", "Finlandia",1865, "00sdg3@gmail.com", "http://www.Empr56esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa153", "Finlandia",1865, "00zxcbz3@gmail.com", "http://www.Empr56esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa154", "Finlandia",1865, "00zbvb3@gmail.com", "http://www.Empre456sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa155", "Finlandia",1865, "00bv3@gmail.com", "http://www.Empres56a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa156", "Finlandia",1865, "0vxcbx03@gmail.com", "http://www.Empre456sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa157", "Finlandia",1865, "00xbvc3@gmail.com", "http://www.Empres456a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa158", "Finlandia",1865, "00bcb3@gmail.com", "http://www.Empre56sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa159", "Finlandia",1865, "00cbc3@gmail.com", "http://www.Empre456sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa160", "Finlandia",1865, "00cbc3@gmail.com", "http://www.Empre456sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa161", "Finlandia",1865, "00cbvc3@gmail.com", "http://www.Empr56sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa162", "Finlandia",1865, "00vbcb3@gmail.com", "http://www.Empre56sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa163", "Finlandia",1865, "0cbvc3@gmail.com", "http://www.Empresa4654.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa164", "Finlandia",1865, "0cbc03@gmail.com", "http://www.Empres46a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa165", "Finlandia",1865, "0bcb03@gmail.com", "http://www.Empres4564a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa166", "Finlandia",1865, "003bvc@gmail.com", "http://www.Empres45646a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa167", "Finlandia",1865, "00bcb3@gmail.com", "http://www.Empresa45644.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa168", "Finlandia",1865, "00bvcbv3@gmail.com", "http://www.Empre5646sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa170", "Finlandia",1865, "0cbvc03@gmail.com", "http://www.Empres5646a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa171", "Finlandia",1865, "00cvbc3@gmail.com", "http://www.Empr5646esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa172", "Finlandia",1865, "00cbvc3@gmail.com", "http://www.Empr4654esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa1773", "Finlandia",1865, "00cbvc3@gmail.com", "http://www.Empr4564esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa173", "Finlandia",1865, "00bvc3@gmail.com", "http://www.Empre4564sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa174", "Finlandia",1865, "00sdfs3@gmail.com", "http://www.Empr564esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa175", "Finlandia",1865, "00sd3@gmail.com", "http://www.Empres654a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa176", "Finlandia",1865, "00sdf3@gmail.com", "http://www.Empr5646esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa177", "Finlandia",1865, "00df3@gmail.com", "http://www.Empre654sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa178", "Finlandia",1865, "00df3@gmail.com", "http://www.Empre5464sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa179", "Finlandia",1865, "0sdf03@gmail.com", "http://www.Empr6646esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa180", "Finlandia",1865, "00jhg3@gmail.com", "http://www.Empre5645sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4180", "Finlandia",1865, "0jyu03@gmail.com", "http://www.Empre45646sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4181", "Finlandia",1865, "00fhsfh3@gmail.com", "http://www.Empr5646esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4182", "Finlandia",1865, "00hsh3@gmail.com", "http://www.Empre645sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4183", "Finlandia",1865, "00sdfh3@gmail.com", "http://www.Empr5646esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4184", "Finlandia",1865, "00kf3@gmail.com", "http://www.Empr6546esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4185", "Finlandia",1865, "00hc3@gmail.com", "http://www.Empre45646sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4186", "Finlandia",1865, "00hjc3@gmail.com", "http://www.Empre4654sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4187", "Finlandia",1865, "003xjx@gmail.com", "http://www.Empre646sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4188", "Finlandia",1865, "003jxj@gmail.com", "http://www.Empre464sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4189", "Finlandia",1865, "003xfgfg@gmail.com", "http://www.Empr3453esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4190", "Finlandia",1865, "00fghfg3@gmail.com", "http://www.Empre4534sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4191", "Finlandia",1865, "00fghf3@gmail.com", "http://www.Empres5646a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4192", "Finlandia",1865, "00ghf3@gmail.com", "http://www.Empres646a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4193", "Finlandia",1865, "00fghf3@gmail.com", "http://www.Empr644esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4194", "Finlandia",1865, "00nbnz3@gmail.com", "http://www.Empre64sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4195", "Finlandia",1865, "00rthjs3@gmail.com", "http://www.Empr343esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa4196", "Finlandia",1865, "00hsh3@gmail.com", "http://www.Empres34a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa41180", "Finlandia",1865, "0bvcv03@gmail.com", "http://www.Empre6456sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa41802", "Finlandia",1865, "00vvvv3@gmail.com", "http://www.Empr646esa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa40000", "Finlandia",1865, "003srrr@gmail.com", "http://www.Empre4646sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa40001", "Finlandia",1865, "00qqqq3@gmail.com", "http://www.Empre646sa4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa41800", "Finlandia",1865, "003q@gmail.com", "http://www.Empresa464.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa41804", "Finlandia",1865, "003s@gmail.com", "http://www.Empres464a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa41801", "Finlandia",1865, "003g@gmail.com", "http://www.Empres4646a4.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa41803", "Finlandia",1865, "003g@gmail.com", "http://www.Empresa3434.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa41806", "Finlandia",1865, "00y@gmail.com", "http://www.Empresa3434.com");
INSERT INTO EMPRESA (nombre, pais, anoCreacion, correo, dirWeb) VALUES("Empresa41809", "Finlandia",1865, "003oo@gmail.com", "http://www.Empre4343sa4.com");


INSERT INTO EMPLEADO VALUES(5,"77380444Y", "Calle de Jose Ortega y Gasset", 4, 28025, "antonio25@gmail.com",645881748,951554751);
INSERT INTO EMPLEADO VALUES(10,"71480144J", "Calle Alcala", 25, 28921, "Cristina58@gmail.com",645871771,null);
INSERT INTO EMPLEADO VALUES(5,"01182184K", "Calle Alcala", 55, 28921, "MartaDolores_1558@gmail.com",645870749,null);
INSERT INTO EMPLEADO VALUES(7,"77780144J", "Paseo de la Castellana", 12, 28015, "Cristina58@gmail.com",645871771,null);
INSERT INTO EMPLEADO VALUES(6,"71988140P", "Paseo de la Castellana", 1, 28025, "Alberto@gmail.com",645871771,951454112);
INSERT INTO EMPLEADO VALUES(8,"71111111A", "Paseo de la Castellana", 45, 28025, "DiegoSergio@gmail.com",625871771,951454151);
INSERT INTO EMPLEADO VALUES(2,"71215584J", "Paseo de la Castellana", 8, 28025, "Manuela_Antonia@gmail.com",605871771,951454131);
INSERT INTO EMPLEADO VALUES(3,"78178855J", "Paseo de la Castellana", 27, 28025, "Leopoldo_Martos@gmail.com",675171771,951454121);
INSERT INTO EMPLEADO VALUES(0,"21466141S", "Calle Espiritu Santo", 20, 28227, "C.Leoplodo8@gmail.com",645881895,951454111);
INSERT INTO EMPLEADO VALUES(7,"20001144J", "Calle Espiritu Santo", 15, 28227, "Cristobal58@gmail.com",645881896,951454141);
INSERT INTO EMPLEADO VALUES(9,"11785658D", "Calle Espiritu Santo", 25, 28227, "Carmen_Machal@gmail.com",644881871,951454151);
INSERT INTO EMPLEADO VALUES(4,"89555555W", "Paseo de Recoletos", 14, 28127, "VeronicaCastillo@gmail.com",64584771,951454150);
INSERT INTO EMPLEADO VALUES(3,"69874521E", "Paseo de Recoletos", 24, 28127, "Juanjo23@gmail.com",65584771,951454171);
INSERT INTO EMPLEADO VALUES(2,"14785293H", "Paseo de Recoletos", 27, 28127, "Pedro58@gmail.com",615871771,951454151);
INSERT INTO EMPLEADO VALUES(2,"70480144J", "Paseo de Recoletos", 11, 28127, "InmaExposito56@gmail.com",645571771,951254051);
INSERT INTO EMPLEADO VALUES(2,"45899999T", "Paseo de Recoletos", 3, 28127, "Patricia_c@gmail.com",645861771,951454151);
INSERT INTO EMPLEADO VALUES(1,"57899951J", "Paseo de Recoletos", 5, 28127, "InmaMora20@gmail.com",645821771,951454151);
INSERT INTO EMPLEADO VALUES(1,"45789912A", "Paseo de Recoletos", 2, 28127, "RosaliaOrtD@gmail.com",64187121,951454151);
INSERT INTO EMPLEADO VALUES(1,"69873333J", "Paseo de Recoletos", 15, 28127, "PacoMolina@gmail.com",64187171,951454151);
INSERT INTO EMPLEADO VALUES(1,"71470147Z", "Paseo de Recoletos", 22, 28127, "CristinaSerrano@gmail.com",609871771,951454151);
INSERT INTO EMPLEADO VALUES(1,"25800000L", "Paseo de Recoletos", 21, 28127, "EvaAguilera@gmail.com",600871770,951454151);
INSERT INTO EMPLEADO VALUES(4,"71480194X", "Calle Virgen del Sagrario", 25, 28027, "JuliaRomero@gmail.com",600071771,null);
INSERT INTO EMPLEADO VALUES(1,"36997777J", "Calle Virgen de LLuc", 25, 28027, "CAnton8@gmail.com",645881191,null);
INSERT INTO EMPLEADO VALUES(2,"71480000Y", "Calle Serrano Galvache", 25, 2900, "Cayetano58@gmail.com",645884722,null);
INSERT INTO EMPLEADO VALUES(6,"78777712J", "Calle Genova", 25, 28023, "IsmaelCano@gmail.com",632885878,null);
INSERT INTO EMPLEADO VALUES(1,"73666615J", "Calle Alcala", 21, 28921, "Cristina45@gmail.com",645871000,null);
INSERT INTO EMPLEADO VALUES(7,"0001554Q", "Calle Alcala", 12, 28921, "Cristina46@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(5,"12367822Q", "Calle Alcala", 12, 28921, "12367822@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(4,"12368881Q", "Calle Alcala", 12, 28921, "12368881@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12321541A", "Calle Alcala", 12, 28921, "12368881Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12388884w", "Calle Alcala", 12, 28921, "1236555lQ@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365544E", "Calle Alcala", 12, 28921, "12321541A@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(8,"12365577Q", "Calle Alcala", 12, 28921, "12388884w@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(9,"12384444T", "Calle Alcala", 12, 28921, "12365544E@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"129999990", "Calle Alcala", 12, 28921, "12365577Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554M", "Calle Alcala", 12, 28921, "12384444T@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(5,"12365550B", "Calle Alcala", 12, 28921, "129999990@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(4,"12365550L", "Calle Alcala", 12, 28921, "12365554M@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(3,"12365552K", "Calle Alcala", 12, 28921, "12365550B@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12365552j", "Calle Alcala", 12, 28921, "12365550L@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365574B", "Calle Alcala", 12, 28921, "12365552K@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(0,"12365222E", "Calle Alcala", 12, 28921, "12365552j@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12368887r", "Calle Alcala", 12, 28921, "12365574B@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(8,"1236555Aw", "Calle Alcala", 12, 28921, "12365222E@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(8,"12365559Y", "Calle Alcala", 12, 28921, "12368887r@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12361114R", "Calle Alcala", 12, 28921, "1236555Aw@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12361223U", "Calle Alcala", 12, 28921, "12365559Y@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"00165554Q", "Calle Alcala", 12, 28921, "12361223U@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12165554Q", "Calle Alcala", 12, 28921, "00165554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12005554Q", "Calle Alcala", 12, 28921, "12065554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12360054Q", "Calle Alcala", 12, 28921, "12165554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365004Q", "Calle Alcala", 12, 28921, "12005554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12360004Q", "Calle Alcala", 12, 28921, "12360054Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"00000000Q", "Calle Alcala", 12, 28921, "12365004Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"00000001Q", "Calle Alcala", 12, 28921, "12360004Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"00000002Q", "Calle Alcala", 12, 28921, "00000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"00000003Q", "Calle Alcala", 12, 28921, "00000001Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"00000004Q", "Calle Alcala", 12, 28921, "00000002Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(3,"00000005Q", "Calle Alcala", 12, 28921, "00000003Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(4,"00000006Q", "Calle Alcala", 12, 28921, "00000004Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(5,"00000007Q", "Calle Alcala", 12, 28921, "00000005Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(6,"00000008Q", "Calle Alcala", 12, 28921, "00000006Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"00000009Q", "Calle Alcala", 12, 28921, "00000007Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(8,"00000010Q", "Calle Alcala", 12, 28921, "00000008Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(9,"00000011Q", "Calle Alcala", 12, 28921, "00000009Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(9,"00000054Q", "Calle Alcala", 12, 28921, "00000010Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"00000554Q", "Calle Alcala", 12, 28921, "00000011Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"00005554Q", "Calle Alcala", 12, 28921, "00000054Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"00065554Q", "Calle Alcala", 12, 28921, "00000554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"00365554Q", "Calle Alcala", 12, 28921, "00005554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"09365554Q", "Calle Alcala", 12, 28921, "00065554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"02365554Q", "Calle Alcala", 12, 28921, "00365554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"10365554Q", "Calle Alcala", 12, 28921, "09365554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12065554Q", "Calle Alcala", 12, 28921, "02365554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12305554Q", "Calle Alcala", 12, 28921, "10365554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12360554Q", "Calle Alcala", 12, 28921, "12065554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12365054Q", "Calle Alcala", 12, 28921, "12305554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12365504Q", "Calle Alcala", 12, 28921, "12360554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12365550Q", "Calle Alcala", 12, 28921, "12365054Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12365104Q", "Calle Alcala", 12, 28921, "12365504Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12365024Q", "Calle Alcala", 12, 28921, "12365550Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12300054Q", "Calle Alcala", 12, 28921, "12365104Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(0,"12000004Q", "Calle Alcala", 12, 28921, "12365054Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12112211Q", "Calle Alcala", 12, 28921, "12300054Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"11111111Q", "Calle Alcala", 12, 28921, "12000004Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365511Q", "Calle Alcala", 12, 28921, "12111111Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365111Q", "Calle Alcala", 12, 28921, "11111111Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12361111Q", "Calle Alcala", 12, 28921, "12365511Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12311111Q", "Calle Alcala", 12, 28921, "12365111Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12111111Q", "Calle Alcala", 12, 28921, "12361111Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"10111111Q", "Calle Alcala", 12, 28921, "12311111Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"10111100Q", "Calle Alcala", 12, 28921, "12111111Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"10011100Q", "Calle Alcala", 12, 28921, "10111111Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12001110Q", "Calle Alcala", 12, 28921, "10111100Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12555000Q", "Calle Alcala", 12, 28921, "10011100Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365110Q", "Calle Alcala", 12, 28921, "12001110Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12111004Q", "Calle Alcala", 12, 28921, "12555000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"18880004Q", "Calle Alcala", 12, 28921, "12365110Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"19889004Q", "Calle Alcala", 12, 28921, "12111004Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12222004Q", "Calle Alcala", 12, 28921, "18880004Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(2,"12300054A", "Calle Alcala", 12, 28921, "19889004Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(10,"12365142f", "Calle Alcala", 12, 28921, "12222004Q6@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365550S", "Calle Alcala", 12, 28921, "12300054A@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(14,"77380000y", "Calle Alcala", 12, 28921, "123651426@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(11,"70777777Q", "Calle Alcala", 12, 28921, "12365550S6@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"22220000Q", "Calle Alcala", 12, 28921, "77380000@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"55550000Q", "Calle Alcala", 12, 28921, "77777777@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"99990000Q", "Calle Alcala", 12, 28921, "22220000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"99910000Q", "Calle Alcala", 12, 28921, "55550000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"33333333Q", "Calle Alcala", 12, 28921, "99990000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"44444444Q", "Calle Alcala", 12, 28921, "99910000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"55555555Q", "Calle Alcala", 12, 28921, "33333333Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"66666666Q", "Calle Alcala", 12, 28921, "44444444Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"72777777Q", "Calle Alcala", 12, 28921, "55555555Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"88888888Q", "Calle Alcala", 12, 28921, "66666666Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"99999999Q", "Calle Alcala", 12, 28921, "77777777Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"10000000C", "Calle Alcala", 12, 28921, "88888888Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"14444444Q", "Calle Alcala", 12, 28921, "99999999Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"15555555Q", "Calle Alcala", 12, 28921, "10000000C@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"16666666Q", "Calle Alcala", 12, 28921, "14444444Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"17777777Q", "Calle Alcala", 12, 28921, "15555555Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"18888888Q", "Calle Alcala", 12, 28921, "16666666Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"19999999Q", "Calle Alcala", 12, 28921, "17777777Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"66660660Q", "Calle Alcala", 12, 28921, "18888888Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"66666000Q", "Calle Alcala", 12, 28921, "19999999Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12333333Q", "Calle Alcala", 12, 28921, "66666666Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12321212Q", "Calle Alcala", 12, 28921, "66666000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365655Q", "Calle Alcala", 12, 28921, "12333333Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365588Q", "Calle Alcala", 12, 28921, "12321212Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"34000000Q", "Calle Alcala", 12, 28921, "12365655Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"35000000Q", "Calle Alcala", 12, 28921, "12365588Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"36000000Q", "Calle Alcala", 12, 28921, "34000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"37000000Q", "Calle Alcala", 12, 28921, "35000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"38000000Q", "Calle Alcala", 12, 28921, "36000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"39000000Q", "Calle Alcala", 12, 28921, "37000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"40000000Q", "Calle Alcala", 12, 28921, "38000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"41000000Q", "Calle Alcala", 12, 28921, "39000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"42000000Q", "Calle Alcala", 12, 28921, "40000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"43000000Q", "Calle Alcala", 12, 28921, "41000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"44000000Q", "Calle Alcala", 12, 28921, "42000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"45000000Q", "Calle Alcala", 12, 28921, "43000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"46000000Q", "Calle Alcala", 12, 28921, "44000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"47004440Q", "Calle Alcala", 12, 28921, "45000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"19000000Q", "Calle Alcala", 12, 28921, "46000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365521Q", "Calle Alcala", 12, 28921, "47004440Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365503Q", "Calle Alcala", 12, 28921, "19000000Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12965594Q", "Calle Alcala", 12, 28921, "12365521Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"123655507Q", "Calle Alcala", 12, 28921,"12365503Q6@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12369999Q", "Calle Alcala", 12, 28921, "12365504Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365480Q", "Calle Alcala", 12, 28921, "123655507@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554v", "Calle Alcala", 12, 28921, "12369999Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554H", "Calle Alcala", 12, 28921, "12365480Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554K", "Calle Alcala", 12, 28921, "12365554v@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554I", "Calle Alcala", 12, 28921, "12365554H@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554T", "Calle Alcala", 12, 28921, "12365554K@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554R", "Calle Alcala", 12, 28921, "12365554I@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554Q", "Calle Alcala", 12, 28921, "12365554T@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365054W", "Calle Alcala", 12, 28921, "12365554R@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365550z", "Calle Alcala", 12, 28921, "12365554Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365550C", "Calle Alcala", 12, 28921, "12365054W@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365555b", "Calle Alcala", 12, 28921, "12365550z@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365556P", "Calle Alcala", 12, 28921, "12365550C@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365559u", "Calle Alcala", 12, 28921, "12365555b@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365557L", "Calle Alcala", 12, 28921, "12365556P@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12375559y", "Calle Alcala", 12, 28921, "12365559u@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365559T", "Calle Alcala", 12, 28921, "12365557L@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554d", "Calle Alcala", 12, 28921, "12365559y@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554x", "Calle Alcala", 12, 28921, "12365559T@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365004m", "Calle Alcala", 12, 28921, "12365554d@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554b", "Calle Alcala", 12, 28921, "12365554x@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554c", "Calle Alcala", 12, 28921, "12365554m@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12065554r", "Calle Alcala", 12, 28921, "12365554b@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12065554t", "Calle Alcala", 12, 28921, "12365554c@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554e", "Calle Alcala", 12, 28921, "12365554r@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(7,"12365554w", "Calle Alcala", 12, 28921, "12365554t@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365554y", "Calle Alcala", 12, 28921, "12365554e@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12360000A", "Calle Alcala", 12, 28921, "12365554w@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365595b", "Calle Alcala", 12, 28921, "12365554y@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365552C", "Calle Alcala", 12, 28921, "12360000A@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12122222Q", "Calle Alcala", 12, 28921, "12365555b@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"17777747Q", "Calle Alcala", 12, 28921, "12365552C@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"10000000a", "Calle Alcala", 12, 28921, "12122222Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"10000001V", "Calle Alcala", 12, 28921, "17777777Q@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365555f", "Calle Alcala", 12, 28921, "10000000a@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365558G", "Calle Alcala", 12, 28921, "10000001V@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365777h", "Calle Alcala", 12, 28921, "12365555f@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365550T", "Calle Alcala", 12, 28921, "12365558G@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365579r", "Calle Alcala", 12, 28921, "12365777h@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365582T", "Calle Alcala", 12, 28921, "12365554T@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365599E", "Calle Alcala", 12, 28921, "12365579r@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365522p", "Calle Alcala", 12, 28921, "12365582T@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365111w", "Calle Alcala", 12, 28921, "12365599E@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12364444T", "Calle Alcala", 12, 28921, "12365522p@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365475o", "Calle Alcala", 12, 28921, "12365111w@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12364252F", "Calle Alcala", 12, 28921, "12364444T@gmail.com",null,null);
INSERT INTO EMPLEADO VALUES(1,"12365544W", "Calle Alcala", 12, 28921, "12365475o@gmail.com",null,null);

INSERT INTO APLICACION VALUES("StoryArt","04/07/19","04/07/18","0124E",1,10,10.25);
INSERT INTO APLICACION VALUES("Tasty","14/01/19","24/07/17","0125F",3,25,10.25);
INSERT INTO APLICACION VALUES("ASOS","04/07/19","04/07/18","0121Q",5,25,15);
INSERT INTO APLICACION VALUES("HBO", "01/05/18","01/11/14","0358w",6,17,1.21);
INSERT INTO APLICACION VALUES("Fitness Femenino", "01/05/12","01/11/10","0347Q",2,17,11.21);
INSERT INTO APLICACION VALUES("Sport", "01/05/09","01/11/10","0357W",9,32,51.21);
INSERT INTO APLICACION VALUES("Netflix", "01/05/16","01/08/18","0874A",8,18,12.2);
INSERT INTO APLICACION VALUES("HUBER", "11/04/16","01/09/14","0311Q",7,25,0.00);
INSERT INTO APLICACION VALUES("Cabiby", "11/01/11","01/09/10","0411W",4,30,0.00);
INSERT INTO APLICACION VALUES("app12", "11/04/16","01/09/14","0318Q",0010,7,0.00);
INSERT INTO APLICACION VALUES("app13", "14/05/19","01/09/14","0126P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app14", "04/07/19","04/07/18","1121Q",0003,25,15);
INSERT INTO APLICACION VALUES("app15", "01/05/18","01/11/14","1358w",0004,17,1.21);
INSERT INTO APLICACION VALUES("app16", "01/05/12","01/11/10","1347Q",0005,17,11.21);
INSERT INTO APLICACION VALUES("app17", "01/05/09","01/11/10","1357W",0006,32,51.21);
INSERT INTO APLICACION VALUES("app18", "01/05/16","01/08/18","1874A",0007,18,12.2);
INSERT INTO APLICACION VALUES("app19", "11/04/16","01/09/14","1311Q",0008,25,0.00);
INSERT INTO APLICACION VALUES("app20", "11/01/11","01/09/10","1411W",0009,30,0.00);
INSERT INTO APLICACION VALUES("app21","11/04/16","01/09/14","0358Q",0010,7,0.00);
INSERT INTO APLICACION VALUES("app22","14/01/19","01/09/14","4151P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app23","14/01/19","01/09/14","4350P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app24","14/01/19","01/09/14","4356P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app25","14/01/19","01/09/14","4351P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app26","14/01/19","01/09/14","4353P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app27","14/01/19","01/09/14","0351P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app28","14/01/19","01/09/14","0355P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app29","14/01/19","01/09/14","0155B",0011,7,0.00);
INSERT INTO APLICACION VALUES("app30","14/01/19","01/09/14","0155N",0011,7,0.00);
INSERT INTO APLICACION VALUES("app31","14/01/19","01/09/14","0155M",0011,7,0.00);
INSERT INTO APLICACION VALUES("app32","14/01/19","01/09/14","0155L",0011,7,0.00);
INSERT INTO APLICACION VALUES("app33","14/01/19","01/09/14","1175A",0011,7,0.00);
INSERT INTO APLICACION VALUES("app34","14/01/19","01/09/14","1175P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app35","14/01/19","01/09/14","1175L",0011,7,0.00);
INSERT INTO APLICACION VALUES("app36", "14/10/19","01/09/14","3751P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app37", "14/10/19","01/09/14","3756P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app38", "14/10/19","01/09/14","3701P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app39", "14/10/19","01/09/14","3753P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app40", "14/10/19","01/09/14","3716P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app41", "14/10/19","01/09/14","3246P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app42", "04/05/19","01/09/14","3256P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app43", "04/05/19","01/09/14","0241M",0011,7,0.00);
INSERT INTO APLICACION VALUES("app44", "04/05/19","01/09/14","0206B",0011,7,0.00);
INSERT INTO APLICACION VALUES("app45", "04/05/19","01/09/14","3251P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app46", "04/05/19","01/09/14","3251W",0011,7,0.00);
INSERT INTO APLICACION VALUES("app47", "04/05/19","01/09/14","3201W",0011,7,0.00);
INSERT INTO APLICACION VALUES("app48", "04/05/19","01/09/14","3211W",0011,7,0.00);
INSERT INTO APLICACION VALUES("app49", "04/05/19","01/09/14","3001W",0011,7,0.00);
INSERT INTO APLICACION VALUES("app50", "04/05/19","01/09/14","3256W",0011,7,0.00);
INSERT INTO APLICACION VALUES("app51", "04/05/19","01/09/14","0216C",0011,7,0.00);
INSERT INTO APLICACION VALUES("app52", "04/05/19","01/09/14","3104P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app53", "04/05/19","01/09/14","0134P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app54", "04/05/19","01/09/14","0124P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app55", "04/05/19","01/09/14","0114P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app56", "11/05/19","01/09/14","1394P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app57", "11/05/19","01/09/14","1294P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app58", "11/05/19","01/09/14","1194P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app59", "11/05/19","01/09/14","1094P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app60", "11/05/19","01/09/14","0194P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app61", "11/05/19","01/09/14","0296P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app62", "11/05/19","01/09/14","4196P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app63", "14/05/19","01/09/14","4096P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app64", "14/05/19","01/09/14","4596P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app65", "10/05/19","01/09/14","4796P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app66", "10/05/19","01/09/14","4296P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app67", "10/05/19","01/09/14","4926P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app68", "10/05/19","01/09/14","4826P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app69", "10/05/19","01/09/14","0826P",0011,7,0.00);
INSERT INTO APLICACION VALUES("app70", "10/05/19","01/09/14","0118P",0011,7,0.00);

INSERT INTO TIENE VALUES("01/01/19","01/01/17","SI","1","0121Q","01182184K");
INSERT INTO TIENE VALUES("02/01/19","01/01/16","NO","2","0125F","11785658D");
INSERT INTO TIENE VALUES("12/01/19","01/01/16","NO","3","0124E","71111111A");
INSERT INTO TIENE VALUES("15/01/19","21/01/16","NO","4","0124E","71215584J");
INSERT INTO TIENE VALUES("17/01/19","11/01/16","NO","5","0126P","89555555W");
INSERT INTO TIENE VALUES("11/01/19","01/01/18","NO","6","0126P","71480000Y");
INSERT INTO TIENE VALUES("15/01/19","11/01/18","NO","7","0126P","78777712J");
INSERT INTO TIENE VALUES("11/05/19","01/01/16","NO","8","0311Q","78178855J");
INSERT INTO TIENE VALUES("11/03/19","01/09/18","NO","9","0126P","71480194X");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","10","0311Q","71480144J");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","11","0311Q","77780144J");
INSERT INTO TIENE VALUES("01/01/19","01/01/17","SI","12","4151P","71988140P");
INSERT INTO TIENE VALUES("02/01/19","01/01/16","NO","13","4350P","71111111A");
INSERT INTO TIENE VALUES("12/01/19","01/01/16","NO","14","4356P","71215584J");
INSERT INTO TIENE VALUES("15/01/19","21/01/16","NO","15","4351P","78178855J");
INSERT INTO TIENE VALUES("17/01/19","11/01/16","NO","16","4353P","21466141S");
INSERT INTO TIENE VALUES("11/01/19","01/01/18","NO","17","0351P","20001144J");
INSERT INTO TIENE VALUES("15/01/19","11/01/18","NO","18","0355P","11785658D");
INSERT INTO TIENE VALUES("11/05/19","01/01/16","NO","19","0155B","89555555W");
INSERT INTO TIENE VALUES("11/03/19","01/09/18","NO","20","0155N","69874521E");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","21","0155M","14785293H");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","22","0155L","70480144J");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","23","1175A","45899999T");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","24" ,"1175P","57899951J");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","25","1175L","45789912A");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","26","3751P","69873333J");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","27","3756P","71470147Z");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","28","3701P","25800000L");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","29","3753P","71480194X");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","30","3716P","36997777J");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","31","3246P","71480000Y");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","32","3256P","78777712J");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","33","0241M","73666615J");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","34","0206B","0001554Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","35","3251P","12367822Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","36","3251W","12368881Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","37","3201W","12321541A");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","38","3211W","12388884w");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","39","3001W","12365544E");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","40","3256W","12365577Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","41","0216C","12384444T");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","42","3104P","129999990");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","43","0134P","12365554M");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","44","0124P","12365550B");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","45","0114P","12365550L");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","46","1394P","12365552K");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","47","1294P","12365552j");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","48","1194P","12365574B");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","49","1094P","12365222E");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","50","0194P","12368887r");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","51","0296P","1236555Aw");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","52","4196P","12365559Y");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","53","4096P","12361114R");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","54","4596P","12361223U");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","55","4796P","00165554Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","56","4296P","12165554Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","57","4926P","12005554Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","58","4826P","12360054Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","59","0826P","12365004Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","60","0118P","12360004Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","61","0125F","00000000Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","62","0121Q","00000001Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","63","0358w","00000002Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","64","0118P","00000003Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","65","0357W","00000004Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","66","0311Q","00000006Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","67","0411W","00000007Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","68","0318Q","00000008Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","69","0126P","00000009Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","70","1121Q","00000010Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","71","1358w","00000011Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","72","1347Q","00000054Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","73","1357W","00000554Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","74","1874A","00005554Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","75","1311Q","00065554Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","76","1411W","00365554Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","77","0358Q","09365554Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","78","4096P","02365554Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","79","4596P","10365554Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","80","4796P","12065554Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","81","4296P","12305554Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","82","4926P","12360554Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","83","4826P","12365054Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","84","0826P","12365504Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","85","0118P","12365550Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","86","0125F","12365104Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","87","0121Q","12365024Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","88","0358w","12300054Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","89","0358w","12000004Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","90","0357W","12112211Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","91","0311Q","11111111Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","92","0411W","12365511Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","93","0318Q","12365111Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","94","0126P","12361111Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","95","1121Q","12311111Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","96","1358w","12111111Q");
INSERT INTO TIENE VALUES("14/10/19","10/01/11","NO","97","1347Q","10111111Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","98","1357W","10111100Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","99","1874A","10011100Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","100","1311Q","12001110Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","101","1411W","12555000Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","102","0358Q","12365110Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","103","0311Q","12111004Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","104","0311Q","18880004Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","105","4151P","19889004Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","106","4350P","12222004Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","107","4356P","12300054A");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","108","4351P","12365142f");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","109","4353P","12365550S");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","110","0351P","77380000y");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","112","0355P","70777777Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","113","0155B","22220000Q");
INSERT INTO TIENE VALUES("04/02/19","10/01/11","NO","114","0155N","55550000Q");
INSERT INTO TIENE VALUES("04/05/19","10/01/11","NO","115","0155M","99990000Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","116","0155L","99910000Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","117","1175A","33333333Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","118","1175P","44444444Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","119","1175L","55555555Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","120","3751P","66666666Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","121","3756P","72777777Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","122","3701P","88888888Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","123","3753P","99999999Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","124","3716P","10000000C");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","125","3246P","14444444Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","126","3256P","15555555Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","127","0241M","16666666Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","128","0206B","17777777Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","129","3251P","18888888Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","130","3251W","19999999Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","131","3201W","66660660Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","132","3211W","66666000Q");
INSERT INTO TIENE VALUES("14/05/19","10/01/11","NO","133","3001W","12333333Q");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","134","3256W","12321212Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","135","0216C","12365655Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","136","0216C","12365588Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","137","0216C","34000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","138","0216C","35000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","139","0216C","36000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","140","0216C","37000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","141","0216C","38000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","142","0216C","39000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","143","0216C","40000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","144","0216C","41000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","145","0216C","42000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","146","0216C","43000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","147","0216C","44000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","148","0216C","45000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","149","0216C","46000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","150","0216C","47004440Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","135","0216C","19000000Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","135","0216C","12365521Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","135","0216C","12365503Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","135","0216C","12965594Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","135","0216C","123655507Q");
INSERT INTO TIENE VALUES("06/02/19","10/01/11","NO","135","0216C","12369999Q");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365480Q");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365554v");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365554H");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365554K");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365554I");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365554T");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365554R");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365554Q");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365054W");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365550z");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365550C");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365555b");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365556P");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","135","0216C","12365559u");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","151","3256W","12365557L");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","151","3256W","12375559y");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","151","3256W","12365559T");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","151","3256W","12365554d");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","151","3256W","12365554x");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","151","3256W","12365004m");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","151","3256W","12365554b");
INSERT INTO TIENE VALUES("14/03/19","10/01/11","NO","151","3256W","12365554c");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","151","3256W","12065554r");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","151","3256W","12065554t");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","151","3256W","12365554e");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","151","3256W","12365554w");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","151","3256W","12365554y");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","151","3256W","12360000A");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","151","3256W","12365595b");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","151","3256W","12365552C");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","151","3256W","12122222Q");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","151","3256W","17777747Q");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","151","3256W","10000000a");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","10000001V");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","12365555f");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","12365558G");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","12365777h");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","12365550T");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","12365579r");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","12365582T");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","12365599E");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","12365522p");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","12365111w");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","12364444T");
INSERT INTO TIENE VALUES("14/04/19","10/01/11","NO","15","3256W","12365475o");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","15","3256W","12364252F");
INSERT INTO TIENE VALUES("14/02/19","10/01/11","NO","15","3256W","12365544W");

INSERT INTO USUARIO VALUES("125545SXf", "Manuel", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27208, "ESPANA", 645881897);
INSERT INTO USUARIO VALUES("025545avf", "Cristina", "Aguilera", "Palomo", "Paseo de recoletos", 6, 27088, "ESPANA", 645881887);
INSERT INTO USUARIO VALUES("154445SXA", "Andrea", "Lopez", "Perez", "Calle Genova", 5, 27088, "ESPANA", 655881897);
INSERT INTO USUARIO VALUES("25545SXf", "Candida", "Cano", "Palomo", "Paseo de la castellana", 7, 27088, "ESPANA", 665881897);
INSERT INTO USUARIO VALUES("325545SXf", "Manuel", "Exposito", "Rodriguez", "Paseo de recoletos", 8, 2708, "ESPANA", 675881897);
INSERT INTO USUARIO VALUES("425545SXf", "Antonio", "Sanchez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 685881897);
INSERT INTO USUARIO VALUES("525545SXf", "Pascual", "Rodriguez", "Fernandez", "Paseo de recoletos", 5, 27088, "ESPANA", 695881897);
INSERT INTO USUARIO VALUES("625545SXf", "Rogelio", "Aguilera", "Lopez", "Paseo de recoletos", 5, 27088, "ESPANA", 641881897);
INSERT INTO USUARIO VALUES("725545SXf", "Alberto", "Rodriguez", "Palomo", "Paseo de recoletos", 9, 27088, "ESPANA", 642881897);
INSERT INTO USUARIO VALUES("825545SXf", "Maria Isabel", "Rodriguez", "Fernandez", "Paseo de recoletos", 5, 27088, "ESPANA", 643881897);
INSERT INTO USUARIO VALUES("925545SXf", "Marta", "Rodriguez", "Lopez", "Paseo de recoletos", 5, 27088, "ESPANA", 644881897);
INSERT INTO USUARIO VALUES("105545SXf", "Maria", "Lopez", "Lopez", "Paseo de recoletos", 5, 27088, "ESPANA", 646881897);
INSERT INTO USUARIO VALUES("115545SXf", "Lola", "Consuegra", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 647881897);
INSERT INTO USUARIO VALUES("135545SXf", "Juan", "Rodriguez", "Gutierrez", "Paseo de recoletos", 5, 27088, "ESPANA", 648881897);
INSERT INTO USUARIO VALUES("145545SXf", "Diego", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 649881897);
INSERT INTO USUARIO VALUES("155545SXf", "Isidoro", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645181897);
INSERT INTO USUARIO VALUES("165545SXf", "Roberto", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645281897);
INSERT INTO USUARIO VALUES("175545SXf", "Cristian", "Cosano", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645883897);
INSERT INTO USUARIO VALUES("185545SXf", "Martin", "Lopez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645884897);
INSERT INTO USUARIO VALUES("195545SXf", "Pedro", "Jiminez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645885897);
INSERT INTO USUARIO VALUES("205545SXf", "Beatriz", "Gallego", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645886897);
INSERT INTO USUARIO VALUES("215545SXf", "Patricia", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645887897);
INSERT INTO USUARIO VALUES("225545SXf", "Inma", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645880897);
INSERT INTO USUARIO VALUES("235545SXf", "Inma", "Consuegra", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645881817);
INSERT INTO USUARIO VALUES("245545SXf", "Marta", "Rodriguez", "Consuegra", "Paseo de recoletos", 5, 27088, "ESPANA", 645881827);
INSERT INTO USUARIO VALUES("255545SXf", "Irene", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645881837);
INSERT INTO USUARIO VALUES("265545SXf", "Andrea", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645881847);
INSERT INTO USUARIO VALUES("275545SXf", "Lucia", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645881857);
INSERT INTO USUARIO VALUES("285545SXf", "Angeles", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645881867);
INSERT INTO USUARIO VALUES("295545SXf", "Concepcion", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645881877);
INSERT INTO USUARIO VALUES("005545SXf", "Manuel", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27088, "ESPANA", 645881887);
INSERT INTO USUARIO VALUES("0005545SXf", "Manuel", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("0000545SXf", "Manuel", "Consuegra", "Palomo", "Paseo de recoletos", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("0000005SXf", "Manuel", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("00000000Xf", "Manuel", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("305540SXA", "Manuel", "Rodriguez", "Consuegra", "Paseo de recoletos", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("305540SXB", "Manuel", "Consuegra", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("305540SXC", "Alberto", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("305540SXD", "Alberto", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("305540SXW", "Alberto", "Consuegra", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("305540SXR", "Alberto", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("305545SXT", "Inma", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Francia", null);
INSERT INTO USUARIO VALUES("305545SXG", "Inma", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Francia", null);
INSERT INTO USUARIO VALUES("301545Saf", "Inma", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Francia", null);
INSERT INTO USUARIO VALUES("301545Sbf", "Inma", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Francia", null);
INSERT INTO USUARIO VALUES("301545Svf", "Inma", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Francia", null);
INSERT INTO USUARIO VALUES("301545SXf", "Inma", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Francia", null);
INSERT INTO USUARIO VALUES("301545SXv", "Alberto", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("301545SXc", "Alberto", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("301545SXa", "Alberto", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("301545SXr", "Alberto", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("301545SXy", "Manuel", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("301545SXq", "Irene", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("30000SXpf", "Irene", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("3055450Xa", "Irene", "Rodriguez", "Palomo", "Paseo de la castellana", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("3055450Xb", "Irene", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("3055450Xc", "Irene", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("3055450Xd", "Irene", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("305545Sjf", "Irene", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27018, "Portugal", null);
INSERT INTO USUARIO VALUES("305565wXf", "Irene", "Rodriguez", "Palomo", "Paseo de recoletos", 5, 27018, "Portugal", null);


INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/05/18","0121Q","025545avf");
INSERT INTO DESCARGA VALUES("Muy malo", 1, "10/05/18","0121Q","105545SXf");
INSERT INTO DESCARGA VALUES("Bueno", 3, "11/04/18","0121Q","115545SXf");
INSERT INTO DESCARGA VALUES("Podria mejorar", 2, "11/05/19","0124E","125545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "01/05/18","0124E","135545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/05/19","0124E","145545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/06/19","0125F","154445SXA");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/07/19","0126P","155545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/08/18","0311Q","165545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/09/18","0318Q","175545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/09/19","0347Q","185545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "10/10/18","0357W","195545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/11/18","0358w","205545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/12/18","0411W","215545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "10/12/18","0874A","225545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/05/17","0874A","235545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/05/16","0874A","245545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/05/15","0874A","25545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/05/14","0874A","255545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/05/13","0874A","265545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/05/12","0874A","275545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/05/10","0411W","285545SXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/05/09","0411W","295545SXf");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","0005545SXf");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","0000545SXf");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","0000005SXf");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","00000000Xf");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","305540SXA");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","305540SXB");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","305540SXC");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","305540SXD");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","305540SXW");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","305540SXR");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","305545SXT");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","305545SXG");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","301545Saf");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","301545Sbf");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","301545Svf");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","301545SXf");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","301545SXv");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","301545SXc");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","301545SXa");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","301545SXr");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","301545SXy");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","301545SXq");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","30000SXpf");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","3055450Xa");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","3055450Xb");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","3055450Xc");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","3055450Xd");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","305545Sjf");
INSERT INTO DESCARGA VALUES("Muy malo ", 2, "11/05/19","0124E","305565wXf");
INSERT INTO DESCARGA VALUES("Muy bueno", 4, "11/05/15","0874A","25545SXf");

INSERT INTO TIENDA VALUES("App Store","http://App1.com","1");
INSERT INTO TIENDA VALUES("Google play Store","http://App2.com","2");
INSERT INTO TIENDA VALUES("App World","http://App3.com","3");
INSERT INTO TIENDA VALUES("MarquetPlace","http://App3.com","4");
INSERT INTO TIENDA VALUES("OviTienda","http://App4.com","5");
INSERT INTO TIENDA VALUES("AppCatalog","http://App5.com","6");
INSERT INTO TIENDA VALUES("AppStore_00","http://App6.com","7");
INSERT INTO TIENDA VALUES("AppsStore_0","http://App7.com","8");
INSERT INTO TIENDA VALUES("AppStore_1","http://App8.com","9");
INSERT INTO TIENDA VALUES("AppStore_2","http://App9.com","10");
INSERT INTO TIENDA VALUES("AppStore_3","http://App10.com","11");
INSERT INTO TIENDA VALUES("AppStore_4","http://App11.com","12");
INSERT INTO TIENDA VALUES("AppStore_4a","http://App12.com","13");
INSERT INTO TIENDA VALUES("AppStore_5","http://App13.com","14");
INSERT INTO TIENDA VALUES("AppStore_6","http://App14.com","15");
INSERT INTO TIENDA VALUES("AppStore_7","http://App15.com","16");
INSERT INTO TIENDA VALUES("AppStore_8","http://App16.com","17");
INSERT INTO TIENDA VALUES("AppStore_9","http://App17.com","18");
INSERT INTO TIENDA VALUES("AppStore_10","http://App18.com","19");
INSERT INTO TIENDA VALUES("AppStore_11","http://App19.com","20");
INSERT INTO TIENDA VALUES("AppStore_12","http://App20.com","23");
INSERT INTO TIENDA VALUES("AppStore_13","http://App20.com","24"  );
INSERT INTO TIENDA VALUES("AppStore_14","http://App20.com","25"  );
INSERT INTO TIENDA VALUES("AppStore_15","http://App20.com","26"  );
INSERT INTO TIENDA VALUES("AppStore_16","http://App20.com","27"  );
INSERT INTO TIENDA VALUES("AppStore_17","http://App20.com","28"  );
INSERT INTO TIENDA VALUES("AppStore_18","http://App20.com","29"  );
INSERT INTO TIENDA VALUES("AppStore_19","http://App20.com","30"  );
INSERT INTO TIENDA VALUES("AppStore_20","http://App20.com","31"  );
INSERT INTO TIENDA VALUES("AppStore_21","http://App20.com","32"  );
INSERT INTO TIENDA VALUES("AppStore_22","http://App20.com","33"  );
INSERT INTO TIENDA VALUES("AppStore_23","http://App20.com","34"  );
INSERT INTO TIENDA VALUES("AppStore_24","http://App20.com","35"  );
INSERT INTO TIENDA VALUES("AppStore_25","http://App20.com","36"  );
INSERT INTO TIENDA VALUES("AppStore_26","http://App20.com","37"  );
INSERT INTO TIENDA VALUES("AppStore_27","http://App20.com","38"  );
INSERT INTO TIENDA VALUES("AppStore_28","http://App20.com","39"  );
INSERT INTO TIENDA VALUES("AppStore_29","http://App20.com","40"  );
INSERT INTO TIENDA VALUES("AppStore_30","http://App20.com","41"  );
INSERT INTO TIENDA VALUES("AppStore_31","http://App20.com","42"  );
INSERT INTO TIENDA VALUES("AppStore_32","http://App20.com","43"  );
INSERT INTO TIENDA VALUES("AppStore_33","http://App20.com","44"  );
INSERT INTO TIENDA VALUES("AppStore_34","http://App20.com","45"  );
INSERT INTO TIENDA VALUES("AppStore_35","http://App20.com","46"  );
INSERT INTO TIENDA VALUES("AppStore_36","http://App20.com","47"  );
INSERT INTO TIENDA VALUES("AppStore_37","http://App20.com","48"  );
INSERT INTO TIENDA VALUES("AppStore_38","http://App20.com","49"  );
INSERT INTO TIENDA VALUES("AppStore_39","http://App20.com","50"  );
INSERT INTO TIENDA VALUES("AppStore_40","http://App20.com","51"  );
INSERT INTO TIENDA VALUES("AppStore_41","http://App20.com","52"  );
INSERT INTO TIENDA VALUES("AppStore_42","http://App20.com","53"  );
INSERT INTO TIENDA VALUES("AppStore_43","http://App20.com","54"  );
INSERT INTO TIENDA VALUES("AppStore_44","http://App20.com","55"  );
INSERT INTO TIENDA VALUES("AppStore_45","http://App20.com","56"  );
INSERT INTO TIENDA VALUES("AppStore_46","http://App20.com","57"  );
INSERT INTO TIENDA VALUES("AppStore_47","http://App20.com","58"  );
INSERT INTO TIENDA VALUES("AppStore_48","http://App20.com","59"  );
INSERT INTO TIENDA VALUES("AppStore_49","http://App20.com","60"  );
INSERT INTO TIENDA VALUES("AppStore_50","http://App20.com","61"  );
INSERT INTO TIENDA VALUES("AppStore_51","http://App20.com","62"  );
INSERT INTO TIENDA VALUES("AppStore_52","http://App20.com","63"  );
INSERT INTO TIENDA VALUES("AppStore_53","http://App20.com","64"  );
INSERT INTO TIENDA VALUES("AppStore_54","http://App20.com","65"  );
INSERT INTO TIENDA VALUES("AppStore_55","http://App20.com","66"  );
INSERT INTO TIENDA VALUES("AppStore_56","http://App20.com","67"  );
INSERT INTO TIENDA VALUES("AppStore_57","http://App20.com","68"  );
INSERT INTO TIENDA VALUES("AppStore_58","http://App20.com","69"  );
INSERT INTO TIENDA VALUES("AppStore_59","http://App20.com","70"  );
INSERT INTO TIENDA VALUES("AppStore_60","http://App20.com","71"  );
INSERT INTO TIENDA VALUES("AppStore_61","http://App20.com","72"  );
INSERT INTO TIENDA VALUES("AppStore_62","http://App20.com","73"  );
INSERT INTO TIENDA VALUES("AppStore_63","http://App20.com","74"  );
INSERT INTO TIENDA VALUES("AppStore_64","http://App20.com","75"  );
INSERT INTO TIENDA VALUES("AppStore_65","http://App20.com","76"  );
INSERT INTO TIENDA VALUES("AppStore_66","http://App20.com","77"  );
INSERT INTO TIENDA VALUES("AppStore_67","http://App20.com","78"  );
INSERT INTO TIENDA VALUES("AppStore_68","http://App20.com","79"  );
INSERT INTO TIENDA VALUES("AppStore_69","http://App20.com","80"  );
INSERT INTO TIENDA VALUES("AppStore_70","http://App20.com","81"  );
INSERT INTO TIENDA VALUES("AppStore_71","http://App20.com","82"  );
INSERT INTO TIENDA VALUES("AppStore_72","http://App20.com","83"  );
INSERT INTO TIENDA VALUES("AppStore_73","http://App20.com","84"  );
INSERT INTO TIENDA VALUES("AppStore_74","http://App20.com","85"  );
INSERT INTO TIENDA VALUES("AppStore_75","http://App20.com","86"  );
INSERT INTO TIENDA VALUES("AppStore_76","http://App20.com","87"  );
INSERT INTO TIENDA VALUES("AppStore_77","http://App20.com","88"  );
INSERT INTO TIENDA VALUES("AppStore_78","http://App20.com","89"  );
INSERT INTO TIENDA VALUES("AppStore_79","http://App20.com","90"  );
INSERT INTO TIENDA VALUES("AppStore_80","http://App20.com","91"  );
INSERT INTO TIENDA VALUES("AppStore_81","http://App20.com","92"  );
INSERT INTO TIENDA VALUES("AppStore_82","http://App20.com","93"  );
INSERT INTO TIENDA VALUES("AppStore_83","http://App20.com","94"  );
INSERT INTO TIENDA VALUES("AppStore_84","http://App20.com","95"  );
INSERT INTO TIENDA VALUES("AppStore_85","http://App20.com","96"  );
INSERT INTO TIENDA VALUES("AppStore_86","http://App20.com","97"  );
INSERT INTO TIENDA VALUES("AppStore_87","http://App20.com","98"  );
INSERT INTO TIENDA VALUES("AppStore_88","http://App20.com","99"  );
INSERT INTO TIENDA VALUES("AppStore_89","http://App20.com","100" );
INSERT INTO TIENDA VALUES("AppStore_90","http://App20.com","101" );
INSERT INTO TIENDA VALUES("AppStore_91","http://App20.com","102" );
INSERT INTO TIENDA VALUES("AppStore_92","http://App20.com","103" );
INSERT INTO TIENDA VALUES("AppStore_93","http://App20.com","104" );
INSERT INTO TIENDA VALUES("AppStore_94","http://App20.com","105" );
INSERT INTO TIENDA VALUES("AppStore_95","http://App20.com","106" );
INSERT INTO TIENDA VALUES("AppStore_96","http://App20.com","107" );
INSERT INTO TIENDA VALUES("AppStore_97","http://App20.com","108" );
INSERT INTO TIENDA VALUES("AppStore_98","http://App20.com","109" );
INSERT INTO TIENDA VALUES("AppStore_99","http://App20.com","110" );
INSERT INTO TIENDA VALUES("AppStore_100","http://App20.com","112" );
INSERT INTO TIENDA VALUES("AppStore_101","http://App20.com","113" );
INSERT INTO TIENDA VALUES("AppStore_102","http://App20.com","114" );
INSERT INTO TIENDA VALUES("AppStore_103","http://App20.com","115" );
INSERT INTO TIENDA VALUES("AppStore_104","http://App20.com","116" );
INSERT INTO TIENDA VALUES("AppStore_105","http://App20.com","117" );
INSERT INTO TIENDA VALUES("AppStore_106","http://App20.com","118" );
INSERT INTO TIENDA VALUES("AppStore_107","http://App20.com","119" );
INSERT INTO TIENDA VALUES("AppStore_108","http://App20.com","120" );
INSERT INTO TIENDA VALUES("AppStore_109","http://App20.com","121" );
INSERT INTO TIENDA VALUES("AppStore_110","http://App20.com","122" );
INSERT INTO TIENDA VALUES("AppStore_111","http://App20.com","123" );
INSERT INTO TIENDA VALUES("AppStore_112","http://App20.com","124" );
INSERT INTO TIENDA VALUES("AppStore_113","http://App20.com","125" );
INSERT INTO TIENDA VALUES("AppStore_114","http://App20.com","126" );
INSERT INTO TIENDA VALUES("AppStore_115","http://App20.com","127" );
INSERT INTO TIENDA VALUES("AppStore_116","http://App20.com","128" );
INSERT INTO TIENDA VALUES("AppStore_117","http://App20.com","129" );
INSERT INTO TIENDA VALUES("AppStore_118","http://App20.com","130" );
INSERT INTO TIENDA VALUES("AppStore_119","http://App20.com","131" );
INSERT INTO TIENDA VALUES("AppStore_120","http://App20.com","132" );
INSERT INTO TIENDA VALUES("AppStore_121","http://App20.com","133" );
INSERT INTO TIENDA VALUES("AppStore_123","http://App20.com","134" );
INSERT INTO TIENDA VALUES("AppStore_124","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_125","http://App20.com","136" );
INSERT INTO TIENDA VALUES("AppStore_126","http://App20.com","137" );
INSERT INTO TIENDA VALUES("AppStore_127","http://App20.com","138" );
INSERT INTO TIENDA VALUES("AppStore_128","http://App20.com","139" );
INSERT INTO TIENDA VALUES("AppStore_129","http://App20.com","140" );
INSERT INTO TIENDA VALUES("AppStore_130","http://App20.com","141" );
INSERT INTO TIENDA VALUES("AppStore_131","http://App20.com","142" );
INSERT INTO TIENDA VALUES("AppStore_132","http://App20.com","143" );
INSERT INTO TIENDA VALUES("AppStore_133","http://App20.com","144" );
INSERT INTO TIENDA VALUES("AppStore_134","http://App20.com","145" );
INSERT INTO TIENDA VALUES("AppStore_135","http://App20.com","146" );
INSERT INTO TIENDA VALUES("AppStore_136","http://App20.com","147" );
INSERT INTO TIENDA VALUES("AppStore_137","http://App20.com","148" );
INSERT INTO TIENDA VALUES("AppStore_138","http://App20.com","149" );
INSERT INTO TIENDA VALUES("AppStore_139","http://App20.com","150" );
INSERT INTO TIENDA VALUES("AppStore_140","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_141","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_142","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_143","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_144","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_145","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_146","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_147","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_148","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_149","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_150","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_151","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_152","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_153","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_154","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_155","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_156","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_157","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_158","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_12222","http://App20.com","135" );
INSERT INTO TIENDA VALUES("AppStore_100002","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore1212A","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore1212C","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore1212D","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore1212F","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore1213D","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12W","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12R","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_2S","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12a","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12v","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12c","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12s","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12q","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12t","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12y","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12u","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12i","http://App20.com","151" );
INSERT INTO TIENDA VALUES("AppStore_12p","http://App20.com","151" );

INSERT INTO PERTENECE VALUES("3211W","AppStore_143");
INSERT INTO PERTENECE VALUES("3001W","AppStore_144");
INSERT INTO PERTENECE VALUES("3256W","AppStore_145");
INSERT INTO PERTENECE VALUES("0216C","AppStore_146");
INSERT INTO PERTENECE VALUES("3104P","AppStore_147");
INSERT INTO PERTENECE VALUES("0134P","AppStore_148");
INSERT INTO PERTENECE VALUES("0124P","AppStore_149");
INSERT INTO PERTENECE VALUES("0114P","AppStore_150");
INSERT INTO PERTENECE VALUES("1394P","AppStore_151");
INSERT INTO PERTENECE VALUES("1294P","AppStore_152");
INSERT INTO PERTENECE VALUES("1194P","AppStore_153");
INSERT INTO PERTENECE VALUES("1094P","AppStore_154");
INSERT INTO PERTENECE VALUES("0194P","AppStore_155");
INSERT INTO PERTENECE VALUES("0296P","AppStore_156");
INSERT INTO PERTENECE VALUES("4196P","AppStore_157");
INSERT INTO PERTENECE VALUES("4096P","AppStore_158");

INSERT INTO CATEGORIA VALUES("1","Fotografia");
INSERT INTO CATEGORIA VALUES("3","Compras");
INSERT INTO CATEGORIA VALUES("5","Deporte");
INSERT INTO CATEGORIA VALUES("6","Deporte");
INSERT INTO CATEGORIA VALUES("10","Entretenimiento");
INSERT INTO CATEGORIA VALUES("2","Comida");
INSERT INTO CATEGORIA VALUES("9","Transporte");
INSERT INTO CATEGORIA VALUES("8","Transporte");
INSERT INTO CATEGORIA VALUES("7","Entretenimiento");
INSERT INTO CATEGORIA VALUES("4","Entretenimiento");
INSERT INTO CATEGORIA VALUES("0","Fantasia");
INSERT INTO CATEGORIA VALUES("11","Accion");

INSERT INTO TIENE_CATEGORIA VALUES("1","0124E");
INSERT INTO TIENE_CATEGORIA VALUES("10","0124E");
INSERT INTO TIENE_CATEGORIA VALUES("5","0121Q");
INSERT INTO TIENE_CATEGORIA VALUES("3","0347Q");
INSERT INTO TIENE_CATEGORIA VALUES("6","0357W");
INSERT INTO TIENE_CATEGORIA VALUES("10","0874A");
INSERT INTO TIENE_CATEGORIA VALUES("2","0411W");
INSERT INTO TIENE_CATEGORIA VALUES("9","0311Q");
INSERT INTO TIENE_CATEGORIA VALUES("8","0311Q");
INSERT INTO TIENE_CATEGORIA VALUES("7","0311Q");
INSERT INTO TIENE_CATEGORIA VALUES("4","0311Q");


-- 1. Obtener todos los empleados que sean jefes.
SELECT * 
FROM EMPLEADO AS E
INNER JOIN TIENE AS T ON T.dniEmpleado = E.DNI
WHERE T.jefe = "SI";
-- 2. Obtener toda la informacion que sea posible de los empleados que sean jefes.
SELECT * 
FROM  TIENE as T, EMPLEADO as E, EMPRESA AS EM, APLICACION AS A 
WHERE A.codigo = T.codigoAplicacion AND E.DNI = T.dniEmpleado AND EM.id = T.idEmpresa AND T.jefe = "SI";
-- 3. Obtener el codigo de las aplicaciones y el id de la categoria para aquellas aplicaciones en las que los empleados son jefes.
SELECT A.codigo , idCategoria 
FROM  TIENE as T, EMPLEADO as E, EMPRESA AS EM, APLICACION AS A
WHERE A.codigo = T.codigoAplicacion AND E.DNI = T.dniEmpleado AND EM.id = T.idEmpresa AND T.jefe = "SI";
-- 4. Obtener el nombre de la categoria o o de las categorias de las aplicaciones para las que los empleados son jefes.alter
SELECT * 
FROM CATEGORIA 
WHERE idCategoria in (SELECT idCategoria 
					  FROM  TIENE as T, EMPLEADO as E, EMPRESA AS EM, APLICACION AS A 
					  WHERE A.codigo = T.codigoAplicacion AND E.DNI = T.dniEmpleado AND EM.id = T.idEmpresa AND T.jefe = "SI");
-- 5. Seleccionar todos los usuarios que hayan puntuado a la aplicacion con codigo = 0411W, con un numero mayor a 3. (La puntuacion estaba restringida a un numero maximo igual a 5, siendo esta, la puntuacion mas alta)
SELECT * 
FROM USUARIO 
WHERE numCuenta in (SELECT numCuentaUsuario 
					FROM DESCARGA 
					WHERE puntuacion > 3 AND codAplicacion = "0411W");
-- 6. Muestra los empleados que trabajen en mas de una empresa, y agrupalos junto al numero de empresas en las que se encuentran trabajando. Ordenalos en sentido descendente.
SELECT dniEmpleado, count(*) as empresas  
FROM TIENE 
GROUP BY idEmpresa 
HAVING empresas > 1 
ORDER BY empresas DESC; 
-- 7. Devuelve el DNI de todos los empleados que no tengan telefono de empresa.
SELECT DNI FROM EMPLEADO WHERE telefonoEmpresa is null;
-- 8. Muestra los paises desde los que el usuario realiza las descargas.
SELECT pais  
FROM USUARIO 
GROUP BY pais;
-- 9. Muestra el pais desde desde donde se realizan mas descargas. Ordenalo en sentido ascendente.
SELECT pais, COUNT(*) veces 
FROM USUARIO 
GROUP BY pais 
ORDER BY veces ASC;
-- 10. Muestra cuantas tiendas gestiona cada empresa. Mostrando para ello el nombre de la tienda y el id de la empresa
SELECT nombre, idEmpresa, COUNT(*) as numeroTiendas 
FROM TIENDA 
GROUP BY idEmpresa 
HAVING numeroTiendas > 1;
-- 11. Averigua el nombre de la tienda a la que pertenece la aplicacion cuyo nombre es: app48.
SELECT nombreTienda 
FROM PERTENECE 
WHERE codApp in (SELECT codigo 
				FROM APLICACION 
				WHERE nombre = "app48");
-- 12. Calcula la media de precio de las aplicaciones
SELECT AVG(precio) FROM APLICACION;
-- 13. Calcula cuantas aplicaciones de la tienda AppStore_143 hay.
SELECT codigoAplicacion, COUNT(*) as numeroApps 
FROM TIENE
WHERE codigoAplicacion = (SELECT codigo
						 FROM APLICACION 
						 WHERE codigo = (SELECT codApp 
										 FROM PERTENECE
										 WHERE nombreTienda = "AppStore_143"))
GROUP BY codigoAplicacion;
-- 14. Selecciona el total de aplicaciones que son desarrolladas por cada empleado, siempre y cuando participe en el desarrollo de mas de una aplicacion.
SELECT DNI, COUNT(codigoAplicacion) AS Total
FROM TIENE as T, EMPLEADO AS E, APLICACION AS A, EMPRESA AS EM
WHERE T.dniEmpleado = E.DNI AND T.codigoAplicacion = A.codigo AND EM.id = T.idEmpresa
GROUP BY DNI
HAVING Total > 1;

-- 15. Calcula el total de empresas que se encuentran registradas en la presente base de datos.
SELECT COUNT(*) FROM EMPRESA;
